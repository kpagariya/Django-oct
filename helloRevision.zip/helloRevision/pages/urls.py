# pages/urls.py
from django.urls import path
from . import views

urlpatterns = [
	# 1. address of the URL (localhost:8000/) , 2. function/class name 3.Alias/name of URL
	path('', views.index, name='home'),

	# localhost:8000/login
	path('login/', views.mylogin, name='myloginpath'),
	path('contactus/',views.contactus, name='mycontact')
]
