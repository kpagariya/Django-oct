
from django.shortcuts import render
from django.http import HttpResponse

#localhost:8000
def index(request):
    #return HttpResponse('<h1>hello</h1>')
    return render(request,'pages/home.html')


#localhost:8000/login
#template
def mylogin(request):
    #return HttpResponse('login.html')
    print("IN Mylogin page")
    return render(request,'pages/login.html')


def contactus(request):
    #return HttpResponse('login.html')
	return render(request,'pages/contact.html')


def myregister(request):
    #return HttpResponse('login.html')
    print("IN Mylogin page")
    return render(request,'pages/resgister.html')