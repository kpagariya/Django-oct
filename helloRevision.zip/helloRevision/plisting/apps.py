from django.apps import AppConfig


class PlistingConfig(AppConfig):
    name = 'plisting'
