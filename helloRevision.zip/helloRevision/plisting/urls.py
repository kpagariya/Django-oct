# pages/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # localhost:8000/plistings
	path('', views.plistingsview, name='plistings'),
    
    #localhost:8000/plistings/search
    path('search/', views.plistingsearch, name='search')
   # path('search/<name>', views.plistingsearch, name='search')
   # path('search/<id>', views.plistingsearch, name='search')

	
]
