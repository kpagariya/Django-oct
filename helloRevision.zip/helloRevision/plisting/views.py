from django.shortcuts import render
from django.urls import path
from django.http import HttpResponse
from . import views

def plistingsview(request):
	return HttpResponse('<h1>I am into property listings page</h1>')

def plistingsearch(request):
	pass
